import ast
import html
import json
import math
import re
import uuid
from collections.abc import Iterator
from decimal import Decimal, InvalidOperation

import httpx
from langchain_core.messages import AIMessage, AIMessageChunk, HumanMessage, ToolMessage
from langchain_core.outputs import ChatGenerationChunk, ChatResult
from langchain_openai import ChatOpenAI

_JSON_NUMBER_RE = re.compile(r"^-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?$")


def _parse_json_float(value: str) -> float:
    """Parse a JSON float without silently overflowing or underflowing."""
    try:
        precise = Decimal(value)
    except InvalidOperation as exc:
        raise ValueError(f"invalid JSON number: {value}") from exc
    converted = float(precise)
    if not math.isfinite(converted) or (precise != 0 and converted == 0.0):
        raise ValueError(f"JSON number is outside the representable float range: {value}")
    return converted


def _safe_literal(value: object) -> bool:
    """Reject non-finite floats nested in an AST fallback value."""
    if isinstance(value, float):
        return math.isfinite(value)
    if isinstance(value, (list, tuple, set)):
        return all(_safe_literal(item) for item in value)
    if isinstance(value, dict):
        return all(_safe_literal(key) and _safe_literal(item) for key, item in value.items())
    return True


def _render_tool_arg(value: object) -> str:
    """Serialize a tool-call argument for the XML wire format.

    The XML parser's literal_eval fallback can put values json.dumps rejects
    (e.g. sets) into tool args; degrade those to str() so one unserializable
    argument cannot fail the whole request, matching the tool-result json
    block handling below.
    """
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, ensure_ascii=False)
    except (TypeError, ValueError):
        return str(value)


def _fix_messages(messages: list) -> list:
    """Sanitize incoming messages for MindIE compatibility.

    MindIE's chat template may fail to parse LangChain's native tool_calls
    or ToolMessage roles, resulting in 0-token generation errors. This function
    flattens multi-modal list contents into strings and converts tool-related
    messages into raw text with XML tags expected by the underlying model.
    """
    fixed = []
    for msg in messages:
        # Flatten content if it's a list of blocks
        if isinstance(msg.content, list):
            parts = []
            for block in msg.content:
                if isinstance(block, str):
                    parts.append(block)
                elif isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
                elif isinstance(msg, ToolMessage) and isinstance(block, dict) and block.get("type") == "json" and "json" in block:
                    # Structured tool results ride the same text channel; serialize
                    # them or the model sees an empty <tool_response>. ToolMessage
                    # only: InputSanitizationMiddleware scans just strings and text
                    # blocks, so a json block smuggled into a genuine user message
                    # would reach the model unescaped if it were rendered here.
                    # Those keep the old drop behavior, as does a block with no
                    # "json" key (rather than emitting a literal "null"). Circular
                    # payloads raise ValueError, other non-serializable values
                    # TypeError; degrade both to str().
                    try:
                        parts.append(json.dumps(block["json"], ensure_ascii=False))
                    except (TypeError, ValueError):
                        parts.append(str(block["json"]))
            text = "".join(parts)
        else:
            text = msg.content or ""

        # Convert AIMessage with tool_calls to raw XML text format
        if isinstance(msg, AIMessage) and getattr(msg, "tool_calls", []):
            xml_parts = []
            for tool in msg.tool_calls:
                args_xml = " ".join(f"<parameter={html.escape(str(k), quote=False)}>{html.escape(_render_tool_arg(v), quote=False)}</parameter>" for k, v in tool.get("args", {}).items())
                xml_parts.append(f"<tool_call> <function={html.escape(str(tool['name']), quote=False)}> {args_xml} </function> </tool_call>")
            full_text = f"{text}\n" + "\n".join(xml_parts) if text else "\n".join(xml_parts)
            fixed.append(AIMessage(content=full_text.strip() or " "))
            continue

        # Wrap tool execution results in XML tags and convert to HumanMessage.
        # Escape the tool output so a result containing a literal "</tool_response>"
        # (e.g. from read_file on an untrusted file, bash output, or an MCP tool the
        # ToolResultSanitizationMiddleware allowlist does not cover) cannot close the
        # framing early and inject trailing text into the turn — matching the escaping
        # already applied to tool-call names/args above.
        if isinstance(msg, ToolMessage):
            tool_result_text = f"<tool_response>\n{html.escape(text, quote=False)}\n</tool_response>"
            fixed.append(HumanMessage(content=tool_result_text))
            continue

        # Fallback to prevent completely empty message content
        if not text.strip():
            text = " "

        fixed.append(msg.model_copy(update={"content": text}))

    return fixed


def _parse_xml_tool_call_to_dict(content: str) -> tuple[str, list[dict]]:
    """Parse XML-style tool calls from model output into LangChain dicts.

    Args:
        content: The raw text output from the model.

    Returns:
        A tuple containing the cleaned text (with XML blocks removed) and
        a list of tool call dictionaries formatted for LangChain.
    """
    if not isinstance(content, str) or "<tool_call>" not in content:
        return content, []

    tool_calls = []
    clean_parts: list[str] = []
    cursor = 0
    for start, end, inner_content in _iter_tool_call_blocks(content):
        clean_parts.append(content[cursor:start])
        cursor = end

        func_match = re.search(r"<function=([^>]+)>", inner_content)
        if not func_match:
            continue
        function_name = html.unescape(func_match.group(1).strip())

        # Ignore nested tool blocks when extracting parameters for this call.
        # Nested `<tool_call>` sections represent separate invocations and
        # their `<parameter>` tags must not leak into the current call args.
        param_source_parts: list[str] = []
        nested_cursor = 0
        for nested_start, nested_end, _ in _iter_tool_call_blocks(inner_content):
            param_source_parts.append(inner_content[nested_cursor:nested_start])
            nested_cursor = nested_end
        param_source_parts.append(inner_content[nested_cursor:])
        param_source = "".join(param_source_parts)

        args = {}
        param_pattern = re.compile(r"<parameter=([^>]+)>(.*?)</parameter>", re.DOTALL)
        for param_match in param_pattern.finditer(param_source):
            key = html.unescape(param_match.group(1).strip())
            raw_value = html.unescape(param_match.group(2).strip())

            # Attempt to deserialize string values into native Python types
            # to satisfy downstream Pydantic validation.
            parsed_value = raw_value
            if raw_value.startswith(("[", "{")) or raw_value in ("true", "false", "null") or _JSON_NUMBER_RE.fullmatch(raw_value):
                try:
                    parsed_value = json.loads(raw_value, parse_float=_parse_json_float)
                except json.JSONDecodeError:
                    try:
                        candidate = ast.literal_eval(raw_value)
                        if _safe_literal(candidate):
                            parsed_value = candidate
                    except (ValueError, SyntaxError):
                        # Raw strings retain the gateway's multiline compatibility.
                        # Structured arguments must be parsed before this decode.
                        parsed_value = _decode_escaped_newlines_outside_fences(raw_value).strip()
                except ValueError:
                    # Preserve the entire argument when JSON numeric conversion
                    # rejects overflow, underflow, or the integer digit limit.
                    # Retrying containers with literal_eval would turn nested
                    # underflowing numbers into zero and bypass this validation.
                    pass
            else:
                parsed_value = _decode_escaped_newlines_outside_fences(raw_value).strip()

            args[key] = parsed_value

        tool_calls.append({"name": function_name, "args": args, "id": f"call_{uuid.uuid4().hex[:10]}"})
    clean_parts.append(content[cursor:])

    return "".join(clean_parts).strip(), tool_calls


def _iter_tool_call_blocks(content: str) -> Iterator[tuple[int, int, str]]:
    """Iterate `<tool_call>...</tool_call>` blocks and tolerate nesting."""
    token_pattern = re.compile(r"</?tool_call>")
    depth = 0
    block_start = -1

    for match in token_pattern.finditer(content):
        token = match.group(0)
        if token == "<tool_call>":
            if depth == 0:
                block_start = match.start()
            depth += 1
            continue

        if depth == 0:
            continue

        depth -= 1
        if depth == 0 and block_start != -1:
            block_end = match.end()
            inner_start = block_start + len("<tool_call>")
            inner_end = match.start()
            yield block_start, block_end, content[inner_start:inner_end]
            block_start = -1


def _decode_escaped_newlines_outside_fences(content: str) -> str:
    """Decode literal `\\n` outside fenced code blocks."""
    if "\\n" not in content:
        return content

    parts: list[str] = []
    cursor = 0
    while cursor < len(content):
        candidates = [(position, delimiter) for delimiter in ("```", "~~~") if (position := content.find(delimiter, cursor)) >= 0]
        if not candidates:
            parts.append(content[cursor:].replace("\\n", "\n"))
            break

        start, delimiter = min(candidates)
        end = content.find(delimiter, start + len(delimiter))
        if end < 0:
            # An unterminated Markdown fence extends to the end of the reply.
            # Preserve it verbatim, including any complete pair that uses the
            # other supported delimiter, to match the streaming decoder.
            parts.append(content[cursor:start].replace("\\n", "\n"))
            parts.append(content[start:])
            break

        parts.append(content[cursor:start].replace("\\n", "\n"))
        end += len(delimiter)
        parts.append(content[start:end])
        cursor = end
    return "".join(parts)


class _EscapedNewlineStreamDecoder:
    """Decode literal `\\n` outside fenced code blocks across streamed chunks.

    `_decode_escaped_newlines_outside_fences` needs the whole reply to pair
    ``` or ~~~ delimiters, and a token-sized chunk rarely contains both, so
    decoding chunks independently would also decode escapes inside fences.
    This decoder carries the fence state between chunks and holds back a
    trailing partial delimiter or `\\n` sequence, so the joined stream equals the
    one-shot decode of the same reply. A fence the stream never closes keeps
    its escapes: an unterminated fence still renders as code.
    """

    def __init__(self) -> None:
        self._fence_delimiter: str | None = None
        self._pending = ""

    def push(self, text: str) -> str:
        """Return the text decodable so far, holding back an undecided tail."""
        data = self._pending + text
        self._pending = ""
        out = []
        while data:
            if self._fence_delimiter is not None:
                fence = data.find(self._fence_delimiter)
                if fence == -1:
                    # The closing delimiter may be split across chunks: emit the
                    # fenced code verbatim and keep a partial closer pending.
                    hold = len(data) - len(data.rstrip(self._fence_delimiter[0]))
                    out.append(data[: len(data) - hold])
                    self._pending = data[len(data) - hold :]
                    break
                # Fenced code through its matching closer stays verbatim.
                delimiter_length = len(self._fence_delimiter)
                out.append(data[: fence + delimiter_length])
                data = data[fence + delimiter_length :]
                self._fence_delimiter = None
                continue

            candidates = [(position, delimiter) for delimiter in ("```", "~~~") if (position := data.find(delimiter)) >= 0]
            if not candidates:
                # Outside a fence the tail may still grow into a delimiter or an
                # escape split across the boundary; hold it back, decode the rest.
                hold = len(data) - len(data.rstrip("`~\\"))
                out.append(_decode_escaped_newlines_outside_fences(data[: len(data) - hold]))
                self._pending = data[len(data) - hold :]
                break
            fence, delimiter = min(candidates)
            # Prose before the opening delimiter decodes; the fence itself does not.
            out.append(_decode_escaped_newlines_outside_fences(data[:fence]))
            out.append(delimiter)
            data = data[fence + len(delimiter) :]
            self._fence_delimiter = delimiter
        return "".join(out)

    def flush(self) -> str:
        """Return text held back for a partial delimiter/`\\n` at stream end."""
        pending, self._pending = self._pending, ""
        return pending


class MindIEChatModel(ChatOpenAI):
    """Chat model adapter for MindIE engine.

    Addresses compatibility issues including:
    - Flattening multimodal list contents to strings.
    - Intercepting and parsing hardcoded XML tool calls into LangChain standard.
    - Handling stream=True dropping choices when tools are present by falling back
      to non-streaming generation and yielding simulated chunks.
    - Fixing over-escaped newline characters from gateway responses.
    """

    def __init__(self, **kwargs):
        """Normalize timeout kwargs without creating long-lived clients."""
        connect_timeout = kwargs.pop("connect_timeout", 30.0)
        read_timeout = kwargs.pop("read_timeout", 900.0)
        write_timeout = kwargs.pop("write_timeout", 60.0)
        pool_timeout = kwargs.pop("pool_timeout", 30.0)

        kwargs.setdefault(
            "timeout",
            httpx.Timeout(
                connect=connect_timeout,
                read=read_timeout,
                write=write_timeout,
                pool=pool_timeout,
            ),
        )
        super().__init__(**kwargs)

    def _patch_result_with_tools(self, result: ChatResult) -> ChatResult:
        """Apply post-generation fixes to the model result."""
        for gen in result.generations:
            msg = gen.message

            if isinstance(msg.content, str):
                # Parse the original payload before display-only newline fixes:
                # replacing escapes inside JSON can corrupt its syntax or values.
                clean_content, extracted_tools = _parse_xml_tool_call_to_dict(msg.content)

                if extracted_tools:
                    msg.content = _decode_escaped_newlines_outside_fences(clean_content).strip()
                    if getattr(msg, "tool_calls", None) is None:
                        msg.tool_calls = []
                    msg.tool_calls.extend(extracted_tools)
                else:
                    # Preserve unparseable XML and the existing prose/code behavior.
                    msg.content = _decode_escaped_newlines_outside_fences(msg.content)
        return result

    def _generate(self, messages, stop=None, run_manager=None, **kwargs):
        result = super()._generate(_fix_messages(messages), stop=stop, run_manager=run_manager, **kwargs)
        return self._patch_result_with_tools(result)

    async def _agenerate(self, messages, stop=None, run_manager=None, **kwargs):
        result = await super()._agenerate(_fix_messages(messages), stop=stop, run_manager=run_manager, **kwargs)
        return self._patch_result_with_tools(result)

    def _stream(self, messages, stop=None, run_manager=None, **kwargs):
        if not kwargs.get("tools"):
            decoder = _EscapedNewlineStreamDecoder()
            for chunk in super()._stream(_fix_messages(messages), stop=stop, run_manager=run_manager, **kwargs):
                if isinstance(chunk.message.content, str):
                    chunk.message.content = decoder.push(chunk.message.content)
                yield chunk
            tail = decoder.flush()
            if tail:
                yield ChatGenerationChunk(message=AIMessageChunk(content=tail))
            return

        # Tool-enabled MindIE requests cannot use native streaming, even when
        # the model's default is streaming=True.
        result = self._generate(messages, stop=stop, run_manager=run_manager, **{**kwargs, "stream": False})
        yield from self._simulate_stream(result)

    async def _astream(self, messages, stop=None, run_manager=None, **kwargs):
        # Route standard queries to native streaming for lower TTFB
        if not kwargs.get("tools"):
            decoder = _EscapedNewlineStreamDecoder()
            async for chunk in super()._astream(_fix_messages(messages), stop=stop, run_manager=run_manager, **kwargs):
                if isinstance(chunk.message.content, str):
                    chunk.message.content = decoder.push(chunk.message.content)
                yield chunk
            # A partial ```/`\n` at the very end must still reach the consumer.
            tail = decoder.flush()
            if tail:
                yield ChatGenerationChunk(message=AIMessageChunk(content=tail))
            return

        # Fallback for tool-enabled requests:
        # MindIE currently drops choices when stream=True and tools are present.
        # We await the full generation and yield chunks to simulate streaming.
        result = await self._agenerate(messages, stop=stop, run_manager=run_manager, **{**kwargs, "stream": False})
        for chunk in self._simulate_stream(result):
            yield chunk

    @staticmethod
    def _simulate_stream(result: ChatResult) -> Iterator[ChatGenerationChunk]:
        """Keep sync/async tool-mode chunking and terminal usage identical."""
        for gen in result.generations:
            msg = gen.message
            content = msg.content
            standard_tool_calls = getattr(msg, "tool_calls", [])
            # Attach the full response's terminal usage to the *last* simulated
            # chunk (OpenAI terminal-frame style) so add_usage() counts it once.
            usage_metadata = getattr(msg, "usage_metadata", None)

            # Yield text in chunks to allow downstream UI/Markdown parsers to render smoothly
            if isinstance(content, str) and content:
                chunk_size = 15
                for i in range(0, len(content), chunk_size):
                    chunk_text = content[i : i + chunk_size]
                    # Without tool calls the last text chunk terminates the stream.
                    is_final_chunk = i + chunk_size >= len(content)
                    chunk_msg = AIMessageChunk(
                        content=chunk_text,
                        id=msg.id,
                        response_metadata=msg.response_metadata if i == 0 else {},
                        usage_metadata=usage_metadata if (not standard_tool_calls and is_final_chunk) else None,
                    )
                    yield ChatGenerationChunk(message=chunk_msg, generation_info=gen.generation_info if i == 0 else None)

                if standard_tool_calls:
                    # Tool-call chunk terminates the stream: carry the usage here.
                    yield ChatGenerationChunk(message=AIMessageChunk(content="", id=msg.id, tool_calls=standard_tool_calls, invalid_tool_calls=getattr(msg, "invalid_tool_calls", []), usage_metadata=usage_metadata))
            else:
                chunk_msg = AIMessageChunk(content=content, id=msg.id, tool_calls=standard_tool_calls, invalid_tool_calls=getattr(msg, "invalid_tool_calls", []), usage_metadata=usage_metadata)
                yield ChatGenerationChunk(message=chunk_msg, generation_info=gen.generation_info)
